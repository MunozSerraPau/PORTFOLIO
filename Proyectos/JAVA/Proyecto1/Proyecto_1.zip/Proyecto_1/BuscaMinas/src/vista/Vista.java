package vista;


/**
 * S'ocupa de mostrar diferents coses, ja sigui, l'array que vulguem mostrar o un missatge.
 */
public class Vista {
    /**
     * Mostrar la array que ens envien
     * @param arrayNum és l'array que volem comprovar
     * @param files Es el nombre de files que té
     * @param columnes Es el nombre de columnes que té
     */
    public static void mostrar_camp_mines (char[][] arrayNum, int files, int columnes) {
        // Creem les variables que necessitem
        char character = 65;
        int numColumn = 1;

        // Mostrem número des de l'1 fins al maxim de columnes - 1 perquè és l'última fila i no la volem.
        System.out.printf("%3s", ' ');
        for (int i = 0; i < columnes; i++) {
            if (i >= columnes-1) {
                System.out.printf("%3s"," ");
            } else if (i >= 1) {
                System.out.printf("%3s",numColumn);
                numColumn += 1;
            } else {
                System.out.printf("%3s"," ");
            }
        }
        System.out.println();
        // Mostrem l'array, però al principi de cada fila li assigna una lletra i va en augment
        for (int i = 0; i < files; i++) {
            if (i >= files-1) {
                System.out.printf("%3s"," ");
            } else if (i >= 1) {
                System.out.printf("%3s",character);
                character += 1;
            } else {
                System.out.printf("%3s"," ");
            }

            for (int j = 0; j < columnes; j++) {
                if (j == columnes-1) {
                    System.out.printf("%3s",arrayNum[i][j]);
                } else {
                    System.out.printf("%3s",arrayNum[i][j]);
                }
            }
            System.out.println();
        }
    }

    /**
     * Mostrem un missatge seleccionat
     * @param pregunta És la frase que hem de mostrar per pantalla
     */
    public static void mostrar_missatge (String pregunta) {

        System.out.println(pregunta);

    }
}
