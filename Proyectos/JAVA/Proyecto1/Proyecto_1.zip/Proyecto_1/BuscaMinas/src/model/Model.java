package model;
import vista.Vista;

/**
 * Té la funció per crear les arrays, rebre i modificar segons el que li arriba ja sigui per trepitjar, posar bandera...
 * S'ocupa de fer les accions del joc
 */
public class Model {

    /************* DADES PRIVADES ***************/
    /* DECLAREM TOTES LES VARIABLES PÚBLIQUES QEU NECESSITAREM */

    private static int columnes;
    private static int files;
    private static int bombes;
    private static char[][] campSolucio;
    private static char[][] campJugador;

    /************* FUNCIONS PUBLIQUES **********************/

    /**
     * Té la funció de crear el taulell de joc segons les files i columnes que hem seleccionat, també li posem les bombes,
     * contem les bombes que hi ha al voltant de cada casella.
     * @param f El número de files que volem que tingui l'array.
     * @param c El número de columnes que volem que tingui l'array.
     * @param b La quantitat de bombes que volem que tingui el joc
     */
    public static void iniciarJoc(int f, int c, int b) {
        /* ASSIGNEM VALORS A LES VARIABLES */
        /* Li sumem +2 per crear una contorn extra ja que ens facilitara algunes comprovacions */
        files = f + 2;
        columnes = c + 2;
        bombes = b;

        /* ASSIGNEM LA GRANDÀRIA DE LA ARRAY */
        campJugador = new char[f][c];
        campSolucio = new char[f][c];

        /* CREEM LES ARRAYS Y LI ASSIGNEM UN SIMBOL A CADA CASELLA */
        campJugador = iniciarCampDeMines('·');
        campSolucio = iniciarCampDeMines(' ');

        /* POSEM LES BOMBES A LES CASELLES */
        campSolucio = posarBombesAleatories();

        /* POSEM EL NÚMERO DE BOMBES QUE HI HA AL VOLTANT */
        campSolucio = comptarBombes();

        /* MOSTREM ELS DOS CAMPS DEL JUGADOR I LA RESPOSTA */
        Vista.mostrar_camp_mines(campJugador, files, columnes);
        //Vista.mostrar_camp_mines(campSolucio, files, columnes); /* ACTIVEM AQUESTA OPCIÓ SI VOLEM VEURE LA RESPOSTA DES D'UN INICI */


        /* VERIFIQUEM SI LA FILA COLUMNA HI HA BOMBA NO O NÚMERO */

        /* MOSTREM MISSATGE PER */
        Vista.mostrar_missatge("Quina fila, Columna vols seleccionar per destapar?");
    }

    /**
     Trepitgem la casella seleccionada, depèn d'on caiguis s'acaba el joc, es mostra una sola casella o es
     * mostra una part de caselles al voltant.
     * @param fil El número de fila que hem seleccionat
     * @param colum El número de columna que hem seleccionat
     * @return El camp visible del jugador amb l'array actualitzada segons el que has trepitjat
     */
    public static char[][] trepitjar (int fil, int colum) {
        // Comprovem si NO esta destapada, si ho esta saltem i no passa res
        if (campJugador[fil][colum] == '·') {
            // Ara comprovem si has trepitjat una bomba
            if (campSolucio[fil][colum] == 'B') {
                // Enviem un missatge conforme has perdut
                System.out.println("Has trepitjat una bomba!");
                // Un altre missatge per mostrar-li la solució
                System.out.println("AQUI LA SOLUCIÓ:");
                // Ensenyem l'array solució amb aquesta funció
                Vista.mostrar_camp_mines(campSolucio, files, columnes);
                // Sortim del programa
                System.exit(1);
            } else if (campSolucio[fil][colum] == ' ') {    // Ara comprovem si has trepitjat un espai
                // Primer de tot copiem l'espai al campJugador que és elq ue veu el jugador.
                campJugador[fil][colum] = campSolucio[fil][colum];
                // Ara com ha detectat un espai iniciem la funció per veure que té al voltant
                comprobarEspais(fil, colum);
            }else {     // Ara copiem le contingut del camp solució al de Jugadors
                campJugador[fil][colum] = campSolucio[fil][colum];
            }
        }
        // Retornem el camp Jugador
        return campJugador;

    }

    /**
     * Funció per posar una bandera a una casella que seleccionem
     * @param fil El número de fila que hem seleccionat
     * @param colum El número de columna que hem seleccionat
     */
    public static void posarBandera (int fil, int colum) {
        // Primer de toto comprovem si la casella seleccionada ja te una bandera
        if (campJugador[fil][colum] == 'X') {
            // Canviem la casella per · conforme has desmarcat la bandera
            campJugador[fil][colum] = '·';
            // Mostrem el camp Jugador
            Vista.mostrar_camp_mines(campJugador, files, columnes);
        } else if (campSolucio[fil][colum] == 'B') {        // Comprovem si la casella seleccionada hi ha una bomba
            System.out.println("Has posat una BANDERA");
            // Assignem un X conforme has posat bandera a la casella
            campJugador[fil][colum] = 'X';
            // Mostrem el camp Jugador
            Vista.mostrar_camp_mines(campJugador, files, columnes);
        } else if (campJugador[fil][colum] < '8') {       // Comprovem si la casella seleccionada ja està destapada en el camp Jugador
            // Mostrem un missatge assegurant que no pots ficar bandera perquè ja està destapada.
            System.out.println("No pots ficar bandera aquí ja esta destapada aquesta casella!");
        } else {
            // Assignem a la casella seleccionada un X assegurat que has posat bandera
            campJugador[fil][colum] = 'X';
            // Mostrem missatge conforme te has salvat
            System.out.println("Te has salvat NO hi havia bomba!");
        }
    }

    /**
     * Comprovem SI el Joc ha acabat
     * @return True si ha acabat o false i encara no
     */
    public static boolean ConsultarSiJocAcabat() {
        // Mirem si la funció és true
        if (comprovarSiHaGuanyat()) {
            // Retornem True
            return true;
        } else {
            // Retornem False
            return false;
        }
    }

    /**************** FUNCIONS PRIVADES **********************/

    /**
     * Creem l'array i l'emplenem de símbols qeu hem seleccionat
     * @param simbol Símbol seleccionat segons el qual volem que aparegui
     * @return L'array amb tot complet segons el símbol que hem seleccionat
     */
    private static char[][] iniciarCampDeMines(char simbol) {
        char[][] arrayBideimensionalInt = new char[files][columnes];

        // For Niuat per emplenar totes les files i columnes de l'array
        for (int i = 0; i < files; i++) {
            for (int j = 0; j < columnes; j++) {
                // Comprovar si estem a la fila 0
                if (i == 0 || i == files-1)
                    // Posem el símbol "-" per millorar l'estètica del camp
                    arrayBideimensionalInt[i][j] = '-';
                else if (j == 0 || j == columnes-1)      // Comprovar si estem a la columna 0
                    // Posem el símbol "|" per millorar l'estètica del camp
                    arrayBideimensionalInt[i][j] = '|';
                else
                    // Si no posem el símbol que hem seleccionat
                    arrayBideimensionalInt[i][j] = simbol;
            }
        }
        // Retornem la array
        return arrayBideimensionalInt;
    }

    /**
     * Funció per assignar bombes a caselles aleatòries
     * @return L'array amb les bombes assignades a les caselles
     */
    private static char[][] posarBombesAleatories () {
        // Creem dos variables temporals per saber la mida del camp de mines
        int filesTemp = files - 2;
        int columnesTmp = columnes - 2;

        // Creem variables que necessitem per assignar les bombes
        int contador = bombes;
        int num1;
        int num2;
        char[][] arrayNormal = campSolucio;

        // Repetim fins que el comptador sigui 0
        while (contador != 0) {
            // Crem un nombre aleatori segons la grandària de la fila
            num1 = (int) (Math.random() * (filesTemp - 1 + 1) + 1);
            // Crem un altre nombre aleatori segons la grandària de la columna
            num2 = (int) (Math.random() * (columnesTmp - 1 + 1) + 1);

            // Comprovem si a la columna hi ha la fila aleatòria hi ha un espai buit
            if (arrayNormal[num1][num2] == (' ')) {
                // Llavors li assignem una bomba a la casella
                arrayNormal[num1][num2] = 'B';
                // Llavors li restem un al comptador
                contador = contador - 1;
            }
        }
        // Retornem la array
        return arrayNormal;
    }

    /**
     * Contem les bombes que té al voltant cada casella i li assignem el número
     * @return El array solució amb els números de les bombes que detecta cada casella
     */
    private static char[][] comptarBombes () {
        // Creem les variables que necessitem
        char[][] campMinesNumBombes = campSolucio;
        int contadorBombes;

        // Fem un for niuat el qual revisa totes les caselles del taulell sense contar les primeres i últimes que és un contorn de decoració.
        for (int i = 1; i < files - 1; i++) {
            for (int j = 1; j < columnes - 1; j++) {
                // Comprovem que la casella que toca no es una bomba si es uan bomba saltem
                if (campSolucio[i][j] != 'B'){
                    // Començem amb el comptador a 0
                    contadorBombes = 0;
                    // Anem comprovant totes les caselles al voltant si té una 'B'
                    if (campSolucio[i-1][j-1] == 'B') {
                        // Si te li sumem 1 a comptador
                        contadorBombes += 1;
                    }
                    if (campSolucio[i-1][j] == 'B') {
                        contadorBombes += 1;
                    }
                    if (campSolucio[i-1][j+1] == 'B') {
                        contadorBombes += 1;
                    }
                    if (campSolucio[i][j-1] == 'B') {
                        contadorBombes += 1;
                    }
                    if (campSolucio[i][j+1] == 'B') {
                        contadorBombes += 1;
                    }
                    if (campSolucio[i+1][j-1] == 'B') {
                        contadorBombes += 1;
                    }
                    if (campSolucio[i+1][j] == 'B') {
                        contadorBombes += 1;
                    }
                    if (campSolucio[i+1][j+1] == 'B') {
                        contadorBombes += 1;
                    }

                    // Mirem si comptador es igual a 0
                    if (contadorBombes == 0) {
                        // Li assignem a la casella un espai
                        campSolucio[i][j] = ' ';
                    } else {
                        // Si té algun número li assignem el número amb aquesta línia
                        campSolucio[i][j] = (char) (contadorBombes + '0');
                    }
                }
            }
        }
        // Retornem el array;
        return campMinesNumBombes;
    }

    /**
     *
     * @return True o false segons si hem acabat el joc o no
     */
    private static boolean comprovarSiHaGuanyat () {
        // Creem les variables que necessitem
        boolean jocAcabat = true;
        int contarBombas = 0;

        // Fem un for niuat per comprovar totes les caselles i contar totes les bombes que estan marcades amb la bandera
        for (int i = 1; i < files - 1; i++) {
            for (int j = 1; j < columnes - 1; j++) {
                // FEum una condició que si on hi ha una bomba esta marcada per una Bandera entra
                if (campJugador[i][j] == 'X' && comprobarBomba(i, j)) {
                    //Sumem +1 cada cop que complexi la condició
                    contarBombas += 1;
                }
            }
        }

        // Si el comptador no és igual a les bombes totals llavors entra
        if (contarBombas != bombes) {
            // Assignem que joc acabat és igual a "false" conforma no ha acabat el joc
            jocAcabat = false;
        } else {        // Si és igual entra
            // Comprovem amb un "for" niuat si les caselles no tenen el · conforma no s'ha trepitjat.
            for (int i = 1; i < files - 1; i++) {
                for (int j = 1; j < columnes - 1; j++) {
                    // Si troba un · entra
                    if (campJugador[i][j] == '·') {
                        // Assignem que jocAcabat és igual a false assegurant que no ha acabat el joc
                        jocAcabat = false;
                        return jocAcabat;
                    }
                }
            }
        }
        // Retorna true o false
        return jocAcabat;
    }

    /**
     * Comprovem si hi ha bomba o no a la casella seleccionada
     * @param fil És la fila que volem comprovar
     * @param col És la columna que volem comprovar
     * @return Retornem true o false depenen si te bomba o no
     */
    private static boolean comprobarBomba(int fil, int col) {
        boolean probaCorrecta = false;

        // Fem la comprovació
        if (campSolucio[fil][col] == 'B'){
            // Assignem la variable True
            probaCorrecta = true;
        }
        return probaCorrecta;
    }

    /**
     * Fem la comprovació de tot el voltant de la casella que havíem seleccionat
     * @param fila És la fila que volem fer la comprovació perquè té un espai
     * @param columna És la columna que volem fer la comprovació perquè té un espai
     */
    private static void comprobarEspais (int fila, int columna) {
        // Fem la comprovació de tot el voltant de la casella
        trepitjar(fila-1,columna-1);
        trepitjar(fila-1,columna);
        trepitjar(fila-1,columna+1);

        trepitjar(fila,columna-1);
        trepitjar(fila,columna+1);

        trepitjar(fila+1,columna-1);
        trepitjar(fila+1,columna);
        trepitjar(fila+1,columna+1);
    }
}

