import controlador.Controlador;

/**
 * Funció per inicialitzar tot el programa
 */
public class Mines {
    /**
     * Funció per iniciar tot el programa
     * @param args Paràmetre que es passa per defecte
     */
    public static void main(String[] args) {
        /* Cridem la funció de jugar que fica en funcionament tot el joc.  */
        Controlador.jugar();
    }
}
