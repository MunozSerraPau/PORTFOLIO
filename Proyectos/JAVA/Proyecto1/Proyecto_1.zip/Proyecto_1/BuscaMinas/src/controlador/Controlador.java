package controlador;
import model.Model;
import vista.Vista;

import java.util.Scanner;

/**
 * Iniciem la classe Controlador que se ocupa de la gran part ja que s'ocupa d'anar preguntant quina acció volem fer en
 * cada ronda, crida totes les funcions per visualitzar el camps de mines...
 */
public class Controlador {
    /************ DADES PUBLIQUES ***************/
    /* DECLAREM TOTES LES VARIABLES PÚBLIQUES QUE NECESSITAREM */
    /**
     * Iniciem la variable de files i li assignem 0
     */
    public static int filesTotales = 0;
    /**
     * Iniciem la variable de columnes i li assignem 0
     */
    public static int columnesTotal = 0;
    /**
     * Iniciem la variable de bombes i li assignem 0
     */
    public static int bombas = 0;
    /**
     * Iniciem l'array bidimensional
     */
    public static char[][] campJug;

    /*********** DADES PRIVADES ***********/
    /* DECLAREM TOTES LES VARIABLES PRIVADES */
    private static Scanner scan = new Scanner(System.in);

    /*********** FUNCIONS PUBLIQUES ************/

    /**
     * Iniciem el joc per començar a jugar
     */
    public static void jugar() {
        /* Creem les variables locals que només farem servir en aquesta funció */
        char opcioMenu;
        int opcioMenuCassellas;
        int fila;
        int columna;
        boolean end = false;

        /* Preguntem amb quantes cassalles vol jugar */
        do {
            /* Mostrem un menu amb les diferents opcions */
            mostrarMenuOpcionsCasellas();
            opcioMenuCassellas = scan.nextInt();
            scan.nextLine();
            /* Depenen de la resposta entrem en una opció o un altre */
            switch (opcioMenuCassellas) {
                case 0:
                    /* Si selecciona el 0 envia un missatge i surt del programa */
                    System.out.println("FINS A LA PRÒXIMA!");
                    System.exit(1);
                    break;

                case 1:
                    /* Guardem les files, caselles i bombes a les variables */
                    filesTotales = 3;
                    columnesTotal = 3;
                    bombas = 2;
                    break;

                case 2:
                    filesTotales = 8;
                    columnesTotal = 8;
                    bombas = 10;
                    break;

                case 3:
                    filesTotales = 16;
                    columnesTotal = 16;
                    bombas = 40;
                    break;

                case 4:
                    filesTotales = 16;
                    columnesTotal = 30;
                    bombas = 99;
                    break;

                default:
                    /* Envia un missatge conforma no ha escrit bé el nùmero i ho ha de repetir */
                    System.out.println("ERROR, TORNA A ESCRIURE EL NUMERO.");
            }
        } while (opcioMenuCassellas > 4 && opcioMenuCassellas < 0); /* Repetim si l'opció no és un nùmero entre el 0 i el 4. */


        /* Iniciem el JOC i passem el nùmero de files, columnes i bombes que hem seleccionat anteriorment */
        Model.iniciarJoc(filesTotales, columnesTotal, bombas);


        /* Preguntem quina acció vol fer Trepitjar, Bandera i Sortir */
        do {
            /* Mostrem el menu i agafem l'Opció que ha escollit */
            mostrarMenuOpcions();
            opcioMenu = scan.next().toUpperCase().trim().charAt(0);

            /* Depend de la resposta fem una acció o un altre */
            switch (opcioMenu) {
                case 'A':
                    /* Enviem missatge i sortim del programa */
                    System.out.println("Has Sortit del Joc, moltes gracies per jugar!");
                    System.exit(1);
                    break;

                case 'B':
                    /* Preguntem la Fila i la Columna en la qual vol ficar la Bandera */
                    fila = escullirFila();
                    columna = escullirColumna();

                    /* Cridem a la funció que fica la bandera */
                    Model.posarBandera(fila, columna);

                    /* Ensenyem el camp de minas amb la Bandera posada */
                    Vista.mostrar_camp_mines(campJug, filesTotales + 2, columnesTotal + 2);
                    break;

                case 'T':
                    /* Preguntem la Fila i la Columna que vol trepitjar */
                    fila = escullirFila();
                    columna = escullirColumna();

                    /* Cridem a la funció que trepitja la casella */
                    campJug = Model.trepitjar(fila,columna);

                    /* Mostrem un missatge i ensenyem el camp de minas amb la casella trepitjada */
                    System.out.println("Te has salvat NO hi havia bomba!");
                    Vista.mostrar_camp_mines(campJug, filesTotales + 2, columnesTotal + 2);
                    break;

                default:
                    /* Si no dona una resposta conforme no ho has escrit bé */
                    System.out.println("ERROR, repeteix la resposta.");
            }

            /* Mirem si el joc ha acabat o no amb la funció */
            end = Model.ConsultarSiJocAcabat();

            /* Si la variable és true entrem */
            if (end == true) {
                /* Mostrem un missatge conforma has guanyat i sortim del programa */
                System.out.println("EL JOC HA ACABAT, ENORA BONA HAS GUANYAT!");
                //Thread.sleep(5*1000);
                System.exit(1);
            }

        }while (!end); /* Repetim fins que la variable "end" no sigui "false" */


    }

    /************ FUNCIONS PRIVADES ************/

    /**
     * Mostrem un menú d'opcións per Acabar el joc, posar bandera o Trepitjar una casella
     */
    private static void mostrarMenuOpcions() {
        System.out.println("MENÚ OPCIONS DE JOC");
        System.out.println("---------------------------------");
        System.out.println("A - Acabar Joc");
        System.out.println("B - Bandera a una Casella ");
        System.out.println("T - Trepitjar Casella");
        System.out.println("---------------------------------");
        System.out.print("Quina opció vols (escriu només la lletra)? ");
    }

    /**
     * Preguntem quina fila vol escollir i la transformem a un nùmero
     * @return El nùmero de la fila que volem
     */
    private static int escullirFila() {
        char lletraFila;
        int fila;

        do {
            System.out.print("Escull una fila:");
            /* Agafem la lletra */
            lletraFila = scan.next().toUpperCase().trim().charAt(0);
            scan.nextLine();
            /* Ho passem a INT */
            fila = lletraFila - 64;
        } while (fila > filesTotales || fila < 1);      //Repetim fins que sigui una lletra que coincideixi amb les que tenim
        return fila;
    }

    /**
     * Preguntem quina columna vol escollir
     * @return El nùmero de la columna que volem
     */
    private static int escullirColumna() {
        int columna;

        do {
            System.out.print("Escull una columna:");
            /* Agafem la lletra */
            columna = scan.nextInt();
            scan.nextLine();
        } while (columna > columnesTotal || columna < 1);   //Repetim fins que sigui un nùmero que coincideixi amb les columnes
        return columna;
    }


    /**
     * Mostrem un menú d'opcións per seleccionar la dificultat del joc
     */
    private static void mostrarMenuOpcionsCasellas() {
        System.out.println("MENÚ DE DIFICULTAT");
        System.out.println("---------------------------------");
        System.out.println("1 - 3x3 (2 bombes)");
        System.out.println("2 - 8x8 (10 bombes)");
        System.out.println("3 - 16x16 (40 bombes)");
        System.out.println("4 - 16x30 (99 bombes)");
        System.out.println("O - Sortir del programa");
        System.out.println("---------------------------------");
        System.out.print("Quina opció vols (escriu només el numero)? ");
    }
}
